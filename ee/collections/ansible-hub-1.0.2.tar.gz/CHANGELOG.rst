=========================
ansible.hub Release Notes
=========================

.. contents:: Topics

v1.0.2
======

Bugfixes
--------

- Fixed an issue where an incompatibility message was indicating the incorrect version.

v1.0.1
======

Minor Changes
-------------

- added additional options for authentication to match controller credential type updates.

v1.0.0
======

Release Summary
---------------

This is the major release of the ``ansible.hub`` collection.
