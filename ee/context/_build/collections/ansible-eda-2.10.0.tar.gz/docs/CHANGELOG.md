---
title: Changelog
---

# v2.10.0 (2025-09-12)

- enhancement: tests for kafka subscription to multiple topics and pattern matching topic (#469) @bzwei
- chore(deps): bump actions/setup-java from 4 to 5 (#468) @[dependabot[bot]](https://github.com/apps/dependabot)
- chore(deps): bump codecov/codecov-action from 5.4.3 to 5.5.0 (#466) @[dependabot[bot]](https://github.com/apps/dependabot)

## Features

- feat: [AAP-51248] add pull_policy parameter to decision_environment (#471) @hsong-rh
- Add Token Based Authentication (#467) @zkayyali812

## Maintenance

- chore(deps): bump actions/setup-python from 5 to 6 (#472) @[dependabot[bot]](https://github.com/apps/dependabot)
- chore(deps): bump codecov/codecov-action from 5.5.0 to 5.5.1 (#473) @[dependabot[bot]](https://github.com/apps/dependabot)
- chore: pre-commit autoupdate (#470) @[pre-commit-ci[bot]](https://github.com/apps/pre-commit-ci)

# v2.9.0 (2025-08-18)

## Enhancements

- feat: [AAP-47707] allow credentials to link to external SMS (#459) @kaiokmo
- feat: [AAP-50566] add uuid parameter to event_stream module (#461) @hsong-rh
- feat: support subscription to multiple topics or by a pattern (#457) @bzwei

## Bugfixes

- fix: [AAP-50916] fix rulebook activation idempotence (#463) @kaiokmo

## Maintenance

- bump to 2.9.0 (#465) @Alex-Izquierdo
- chore(deps): bump actions/checkout from 4 to 5 (#464) @[dependabot[bot]](https://github.com/apps/dependabot)
- chore: pre-commit autoupdate (#460) @[pre-commit-ci[bot]](https://github.com/apps/pre-commit-ci)
- chore(deps): bump actions/download-artifact from 4 to 5 (#462) @[dependabot[bot]](https://github.com/apps/dependabot)

# v2.8.2 (2025-07-22)

## Bugfixes

- Azure servicebus - add async functionality (#451) @susanhooks
- fix: [AAP-41467] don't fail on project sync already in progress (#449) @kaiokmo

## Maintenance

- chore: bump to 2.8.2 (#454) @ptoscano
- chore: pre-commit autoupdate (#453) @[pre-commit-ci[bot]](https://github.com/apps/pre-commit-ci)
- docs: point to galaxy docs in metadata (#450) @Alex-Izquierdo

# v2.8.1 (2025-06-24)

## Bugfixes

- fix: slightly improve wait_for logic in project integration test (#441) @kaiokmo
- sanitize hostname URL with startswith validation (#438) @djdanielsson
- fix: [AAP-41454] adjust project url edit test (#439) @kaiokmo
- fix: really check all the URLs in url_check (#432) @ptoscano

## Maintenance

- chore: bump to 2.8.1 (#447) @Alex-Izquierdo
- ci: update ruff exclusions and disable activation test (#448) @Alex-Izquierdo
- chore: pre-commit autoupdate (#443) @[pre-commit-ci[bot]](https://github.com/apps/pre-commit-ci)
- chore: remove darglint  (#440) @Dostonbek1
- chore: add ruff to github workflow (#429) @Dostonbek1
- chore: pre-commit autoupdate (#335) @[pre-commit-ci[bot]](https://github.com/apps/pre-commit-ci)
- chore: disable pylint too-many-positional-arguments (#436) @ptoscano
- update config (#437) @Alex-Izquierdo
- chore: fix the dependabot configuration (#434) @ptoscano
- Bump codecov/codecov-action from 4.5.0 to 5.1.2 (#374) @[dependabot[bot]](https://github.com/apps/dependabot)
- tests: generate certs at test time using sscg (#433) @ptoscano

# v2.8.0 (2025-05-14)

## Enhancements

- ADD scm_branch to project module (#364) @chris93111

## Bugfixes

- fix: remove duplicates and update mismatched python versions in tox.yml (#428) @Dostonbek1
- fix: update links in README (#427) @Dostonbek1

## Maintenance

- chore: release 2.8.0 (#430) @bzwei

# v2.7.0 (2025-04-17)

## Enhancements

- fix: pass in optional arguments to sqs (#421) @mkanoor

## Bugfixes

- fix: [AAP-42971] fix syntax issues in event source plugins (#419) @Dostonbek1
- fix: Correct variable alias to be 'aap_validate_certs' (#422) @zkayyali812

# v2.6.1 (2025-03-31)

New release with no changes from v2.6.0, in order to trigger plugin documentation generation on Automation Hub.

# v2.6.0 (2025-03-04)

## Enhancements

- feat: [AAP-37428] add support for copy credential (#399) @Dostonbek1
- feat [AAP-37306]: add support for copy activations (#400) @kaiokmo

## Other

- Fix YAML syntax issues in DOCUMENTATION (#402) @sivel

# v2.5.0 (2025-02-12)

## Enhancements

- feat: [AAP-38755] add documentation for pg_listener, range, tick, url_check and webhook plugins (#392) @Dostonbek1
- feat: [AAP-38755] add documentation for generic, journald and kafka plugins (#391) @Dostonbek1
- feat: [AAP-38755] add documentation for azure_service_bus, file and file_watch plugins (#390) @Dostonbek1
- feat: [AAP-38755] add documentation for alertmanager, aws_cloudtrail and aws_sqs_queue plugins (#389) @Dostonbek1
- feat: [AAP-38755] add documentation for event filter plugins (#388) @Dostonbek1

# v2.4.0 (2025-01-29)

## Enhancements

- feat: support kwargs for pg conn in pg_listener (#383) @Alex-Izquierdo

## Bugfixes

- fix: AAP-39412 incorrect credential in examples (#384) @kaiokmo

# v2.3.1 (2025-01-21)

## Bugfixes

- Fix mypy issue (#380) @alinabuzachis
- Check if param flag values are defined, not truthiness (#366) @zjleblanc

# v2.3.0 (2024-12-09)

## Enhancements

- feat: optionally check if all env vars match (#350) @mkanoor

## Bugfixes

- ci: make publication only run with tags (#355) @Alex-Izquierdo
- fix: ensure mandatory params for activation (#352) @Alex-Izquierdo
- fix: Avoid QueueFull exception in file_watch source plugin (#342) @Alex-Izquierdo

# v2.2.0 (2024-10-14)

## Enhancements

- feat: add sync capability to project module (#332) @Alex-Izquierdo

## Bugfixes

- Ensure that the mandatory fields required by the EDA API are respected within the modules. (#319) @alinabuzachis
- fix: remove event_stream_type for event_stream module (#339) @Alex-Izquierdo
- Ensure modules are idempotent (#320) @alinabuzachis
- event_stream - Ensure forward_events works as expected (#337) @alinabuzachis
- Fix integration tests (#336) @alinabuzachis

# v2.1.0 (2024-09-16)

## Enhancements

- Rename activation and activation_info  modules (#318) @alinabuzachis
- event_stream - add support for headers and forward_events options (#321) @alinabuzachis

## Bugfixes

- fix: ensure correct required params for event streams (#325) @Alex-Izquierdo
- activation - rename webhooks option to event_streams and add rulebook_info module (#316) @alinabuzachis
- fix: update log_level and restart_policy default values (#322) @Alex-Izquierdo
- Refactor docs building and make changelog visible in web interface (#314) @ssbarnea
- Fix CONTROLLER_HOST environment variable (#311) @Alex-Izquierdo

# v2.0.0 (2024-09-05)

## Major

- Require ansible-core>=2.15 and fix requirements (#236) @ssbarnea

## Enhancements

- Add event_stream and event_stream_info modules (#296) @alinabuzachis
- Enable changelogs for collection (#230) @Akasurde
- Add support for AAP 2.4 (#281) @Akasurde
- Cleanup module_utils and ensure consistence in the code base (#275) @alinabuzachis
- Run integration tests in CI (#274) @alinabuzachis
- Add user module (#257) @Akasurde
- Add activation and activation_info modules (#254) @alinabuzachis
- Add controller_token module (#256) @Akasurde
- Update README to match the template (#237) @alinabuzachis
- Add schemas for our source plugins (#198) @mkanoor
- Add credential and credential_info modules (#251) @alinabuzachis
- Add decision environment module (#248) @Akasurde
- Add credential_type module (#240) @alinabuzachis
- Add project module (#238) @Akasurde
- Added a demo rulebook with webhooks (#247) @mkanoor
- Add module_utils (#244) @alinabuzachis
- Add support for python 3.12 (#243) @ssbarnea
- Generic source supports events in yaml file (#215) @mkanoor

## Bugfixes

- Generate CHANGELOG.md using github release-drafter (#300) @ssbarnea
- Fix CHANGELOG reference path into README (#294) @alinabuzachis
- fix: raise OperationalError and Decoding Errors (#293) @mkanoor
- Add more types (#282) @ssbarnea
- Untrack antsibull-docs generated files (#285) @ssbarnea
- Ensure that mypy results are consistent (#286) @ssbarnea
- Update anstibull-docs (#284) @ssbarnea
- Add docs building and testing (#276) @ssbarnea
- Add some critical types to module_utils and fix logic (#270) @ssbarnea
- Remove test module (#266) @Akasurde
- Refactor plugins/module_utils/controller.py for better testing (#249) @alinabuzachis
- Address arg-type, return and return-value type errors (#261) @ssbarnea
- Ignore common linting rules (#242) @Akasurde
- Correct psycopg requirements (#225) @ssbarnea
- Upgrade linters and refactor how they run (#221) @ssbarnea
- Added a simple rulebook to docs for for demo purposes (#211) @mkanoor
- Support headers (#208) @clyang82

# v1.4.7 (2024-05-21)

## What's Changed
* feat: add raise_error and log_error option to insert_hosts_to_meta filter by @bzwei in https://github.com/ansible/event-driven-ansible/pull/197
* chore: fixed examples to use vars instead of jinja by @mkanoor in https://github.com/ansible/event-driven-ansible/pull/201
* feat: enable webhook mTLS support by @bzwei in https://github.com/ansible/event-driven-ansible/pull/205

## New Contributors
* @msmagnanijr made their first contribution in https://github.com/ansible/event-driven-ansible/pull/204

# v1.4.6 (2024-05-20)

## What's Changed
* feat: add raise_error and log_error option to insert_hosts_to_meta filter by @bzwei in https://github.com/ansible/event-driven-ansible/pull/197
* chore: fixed examples to use vars instead of jinja by @mkanoor in https://github.com/ansible/event-driven-ansible/pull/201
* feat: enable webhook mTLS support by @bzwei in https://github.com/ansible/event-driven-ansible/pull/205

## New Contributors
* @msmagnanijr made their first contribution in https://github.com/ansible/event-driven-ansible/pull/204

**Full Changelog**: https://github.com/ansible/event-driven-ansible/compare/v1.4.5...v1.4.6

# v1.4.5 (2024-02-07)

# v1.4.4 (2024-02-07)

# v1.4.3 (2023-09-21)

Features:
- New HMAC verification for webhook plugin
- Fix a bug related with duplicated events in awx cloudtrail plugin

# v1.4.2 (2023-06-28)

# v1.4.1 (2023-06-27)

Added galaxy tags and bumped version v1.4.1

# v1.4.0 (2023-06-27)

# v1.3.8 (2023-05-11)

# v1.3.7 (2023-05-10)

# v1.3.6 (2023-05-08)
